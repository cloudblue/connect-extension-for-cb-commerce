define([], function() {
 var APS_STATUS = {
    CONFIGURING: 'aps:configuring',
    PROVISIONING: 'aps:provisioning',
    READY: 'aps:ready'
  };

  return {
    APS_STATUS: APS_STATUS
  };
});
